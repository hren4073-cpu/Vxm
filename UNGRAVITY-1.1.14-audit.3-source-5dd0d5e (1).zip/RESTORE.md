# Восстановление 1.1.14-audit.3

Точный SHA: `5dd0d5e07d2d745c78758c03b363f1610d78bc52`.
После распаковки ZIP выполните `sha256sum -c SHA256SUMS`.
Самостоятельный снимок кода: распакуйте `source-5dd0d5e.tar.gz` в новую папку.
Нового установочного JAR в пакете нет; тесты Minecraft ещё не запускались.

Для восстановления истории используйте клон ReforkDescnt с базой `93baf2a4926428e7a21f515c2927eb3a5a511413`:

```bash
git bundle verify /absolute/path/recovery-series.bundle
git fetch /absolute/path/recovery-series.bundle refs/heads/codex/ungravity-cloud-recovery-20261024:refs/heads/audit3-restored
git switch audit3-restored
git rev-parse HEAD
```

Ожидаемый HEAD: `5dd0d5e07d2d745c78758c03b363f1610d78bc52`. Такой импорт проверен в отдельном временном репозитории.
Не применяйте bundle и patch одновременно к одной ветке. `all-recovery.patch` начинается
с `93baf2a`, `placement-stage.patch` — с `e32fe0a`. Не делайте force/reset/merge PR9.
GHA остаётся на паузе до нового указания пользователя.

Для повторения standalone-проверок нужны Java21, ECJ и JUnit console. Исходники тестов:
`src/test/java/com/terminaldetector/drmd/PlacementTransactionTest.java` и `LoadedChunkRayTest.java`;
production-классы: `world/build/PlacementTransaction.java` и `world/edit/LoadedChunkRay.java`.
Полная Fabric-проверка потребует разрешения Loom и остальных зависимостей; чистые тесты
и синтаксический parser её не заменяют.
